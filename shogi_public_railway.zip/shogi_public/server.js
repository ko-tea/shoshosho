const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = Number(process.env.PORT) || 8080;
const HOST = '0.0.0.0';
const PUBLIC = path.join(__dirname, 'public');
const rooms = new Map();

function send(ws, obj) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj));
}
function roomState(room) {
  return { type:'state', board:room.board, turn:room.turn, hands:room.hands, lastMove:room.lastMove || null };
}
function broadcast(room, obj) {
  for (const c of room.clients) send(c, obj);
}
function initialRoom() {
  return { clients:new Set(), board:null, turn:'sente', hands:null, lastMove:null, finished:false, cleanup:null };
}
function scheduleCleanup(code, room) {
  if (room.cleanup) clearTimeout(room.cleanup);
  if (room.clients.size === 0 && !room.finished) {
    room.cleanup = setTimeout(() => {
      if (rooms.get(code) === room && room.clients.size === 0) rooms.delete(code);
    }, 60000);
  }
}

const server = http.createServer((req,res)=>{
  let url;
  try { url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); } catch { res.writeHead(400); return res.end('Bad Request'); }
  let file = url.pathname === '/' ? 'index.html' : url.pathname.replace(/^\/+/, '');
  if (file.includes('..')) { res.writeHead(403); return res.end('Forbidden'); }
  const full = path.join(PUBLIC,file);
  fs.stat(full,(err,st)=>{
    if (err || !st.isFile()) { res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'}); return res.end('Not Found'); }
    const ext=path.extname(full);
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-cache'});
    fs.createReadStream(full).pipe(res);
  });
});

const wss = new WebSocketServer({ server });

wss.on('connection',(ws,req)=>{
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const code = (url.searchParams.get('room') || '').trim().toUpperCase();
  if (!code || !/^[A-Z0-9_-]{1,32}$/.test(code)) {
    send(ws,{type:'error',message:'ルームコードが正しくありません。'}); return ws.close();
  }
  let room=rooms.get(code);
  if (!room) { room=initialRoom(); rooms.set(code,room); }
  if (room.clients.size >= 2) { send(ws,{type:'error',message:'このルームは満員です。'}); return ws.close(); }
  if (room.cleanup) { clearTimeout(room.cleanup); room.cleanup=null; }
  room.clients.add(ws);
  send(ws,{type:'room',players:room.clients.size});
  broadcast(room,{type:'room',players:room.clients.size});
  if (room.board) send(ws,roomState(room));

  ws.on('message',data=>{
    let m; try { m=JSON.parse(data.toString()); } catch { return; }
    if (m.type==='ping') return send(ws,{type:'pong'});
    if (m.type==='state') {
      if (!room.board) {
        room.board=m.board; room.turn=m.turn; room.hands=m.hands; room.lastMove=m.lastMove||null;
      } else if (room.clients.size === 1) {
        room.board=m.board; room.turn=m.turn; room.hands=m.hands; room.lastMove=m.lastMove||null;
      }
      broadcast(room,roomState(room));
      return;
    }
    if (m.type==='gameOver') {
      room.finished=true;
      broadcast(room,{type:'gameOver',reason:String(m.reason||'対局終了')});
      return;
    }
  });
  ws.on('close',()=>{
    room.clients.delete(ws);
    broadcast(room,{type:'room',players:room.clients.size});
    scheduleCleanup(code,room);
  });
});

setInterval(()=>{
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive=true;
    ws.ping();
  }
},20000);

server.listen(PORT,HOST,()=>console.log(`Online shogi server listening on ${HOST}:${PORT}`));
